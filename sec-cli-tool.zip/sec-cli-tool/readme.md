python main.py --image dts-data-service --scan-type vulnerabilities --output report.txt

python main.py --image dts-data-service:latest --scan-type vulnerabilities malware --output report.txt

python main.py --image dts-data-service:latest --scan-type vulnerabilities malware --output report.txt

python main.py --image dts-data-service:latest --scan-type vulnerabilities --scan-type malware --output report.txt

python main.py --image dts-data-service:latest --scan-type vulnerabilities --scan-type dependencies --scan-type malware --output report.txt

python main.py --image dts-data-service:latest --scan-type vulnerabilities --scan-type dependencies --scan-type malware --output report.txt

python main.py --image dts-data-service:latest --scan-type vulnerabilities --scan-type dependencies --scan-type malware --output report.txt

python main.py --image dts-data-service:latest --scan-type vulnerabilities --scan-type dependencies --scan-type malware --scan-type secrets --output report.txt

python main.py --image test-secrets-image:latest --scan-type vulnerabilities --scan-type dependencies --scan-type malware --scan-type secrets --output report.txt

python main.py --image test-secrets-image:latest --scan-type vulnerabilities --scan-type dependencies --scan-type malware --scan-type secrets --output report.txt

python main.py --image test-secrets-image:latest --scan-type secrets --output report.txt

python secscan.py --image test-secrets-image:latest --scan-type vulnerabilities --scan-type dependencies --scan-type secrets --output report.txt

python main.py --image test-secrets-image:latest --scan-type vulnerabilities --scan-type dependencies --scan-type malware --scan-type secrets --output report.txt

python cli.py scan --image dts-data-service:latest --scan-type vulnerabilities --scan-type dependencies --scan-type malware --scan-type secrets --output report.txt


python cli.py scan --image test-secrets-image:latest --scan-type secrets --output report.txt
